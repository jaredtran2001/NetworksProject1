Jared Tran: jtran9
Elena Wu: elenawu
Julian Burrington: jburri 

Instructions
In terminal run:
python3 Part2.py