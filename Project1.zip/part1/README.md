Jared Tran: jtran9
Elena Wu: elenawu
Julian Burrington: jburri 

Secrets
[67, 64, 1, 1]

Instructions
In terminal run :
python3 Part1.py <"Server Address">
i.e. python3 Part1.py attu2.cs.washington.edu

